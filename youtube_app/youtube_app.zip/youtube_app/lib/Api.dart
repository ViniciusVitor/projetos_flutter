import 'package:http/http.dart' as http;
import 'dart:convert';

const CHAVE_YOUTUBE_API = "AIzaSyDzkqwXSCZ-Jn2N5LiYNNdJR19rXWihPGI";
const ID_CANAL = "UCZbgt7KIEF_755Xm14JpkCQ";
const URL_BASE = "https://www.googleapis.com/youtube/v3/";



class Api{
  pesquisar(String pesquisa) async{
    http.Response response = await http.get(
        URL_BASE + "search"
            "?part=snippet"
            "&type=video"
            "*maxResults=10"
            "&order=date"
            "&key=$CHAVE_YOUTUBE_API"
            "&channelId=$ID_CANAL"
            "&q=$pesquisa"
    );

    if(response.statusCode == 200){
      //print("resultado: "+ response.body);

      Map<String, dynamic> dadosJson = json.decode(response.body);



    }else{

    }

  }
}


